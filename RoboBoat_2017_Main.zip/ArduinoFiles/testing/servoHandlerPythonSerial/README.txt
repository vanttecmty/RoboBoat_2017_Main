Hecho para Arduino Uno debido a los puertos PWM

Logra establecer la comunicación con los motores pero no es constante.

Solo logra enviar una vez cada X intentos.

Cuando logra llegar a los servomotores, esos parecen moverse adecuadamente y conforme a la información enviada.

Este código esta hecho para funcionar con el código controls.py ubicado ../../../controls.py


