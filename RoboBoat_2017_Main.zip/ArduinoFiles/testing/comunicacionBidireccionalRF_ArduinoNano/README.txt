Códigos hechos para trabajar en conjunto y establecer comunicación Bidireccional con Modulos de Radiofrecuencia de 315 Mhz

Envían Strings de datos entre ellos y particularmente envian strings definidos desde el arduino uno. Los cuales serán decodificados por el arduino nano.