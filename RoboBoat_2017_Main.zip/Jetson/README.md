# RoboBoat_2017_Main
map.py contiene las funciones para actualizar el mapa de los alrededores del barco.
buoy_DBSCAN.py contiene la detección de boyas por color y utiliza clustering(DBSCAN) para juntar pixeles del mismo color que son del mismo objeto.

La carpeta TensorRT contiene el modelo de caffe para la detección de  boyas usando el sistema de inferencia TensorRT.

