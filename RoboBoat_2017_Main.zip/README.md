# RoboBoat_2017_Main
Main Code for RoboBoat Competition

test_path.py for comparing pathfinding version 1, 2 and 3. Version 2 is the fastest.

obtain_data.py is for saving in a file all the sensors that the boat is reading.

xbee.py sends and receives data using the xbees.


